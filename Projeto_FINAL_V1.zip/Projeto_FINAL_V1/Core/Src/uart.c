#include "uart.h"
#include "FreeRTOS.h"
#include "semphr.h"

#define GPIOAEN (1U<<0)
#define UART2EN (1U<<17)

#define CR1_TE (1U<<3)
#define CR1_RE (1U<<2)
#define CR1_UE (1U<<13)
#define SR_TXE (1U<<7)
#define SR_RXNE (1U<<5)

#define SYS_FREQ 16000000
#define APB1_CLK SYS_FREQ

#define UART_BAUDRATE 115200

static void uart_set_baudrate(USART_TypeDef *USARTx, uint32_t PeriphClk, uint32_t BaudRate);
static uint16_t compute_uart_bd(uint32_t PeriphClk, uint32_t BaudRate);
static void uart_check_error(USART_TypeDef *USARTx);  // Função de verificação de erro

void uart2_tx_init(void);
void uart2_write(int ch);
char uart2_read(void);

SemaphoreHandle_t xUARTSemaphore;  // Semáforo para sincronizar a leitura/escrita

// Função para enviar um caractere via UART
int __io_putchar(int ch) {
    uart2_write(ch);
    return ch;
}

// Função de inicialização da UART2
void uart2_rxtx_init(void) {
    // Habilita o clock do GPIOA
    RCC -> AHB1ENR |= GPIOAEN;

    // Configura os pinos do GPIOA para UART2 (TX e RX)
    GPIOA->MODER &=~(1U<<4);
    GPIOA->MODER |= (1U<<5);
    GPIOA->AFR[0] |= (1U<<8);
    GPIOA->AFR[0] |= (1U<<9);
    GPIOA->AFR[0] |= (1U<<10);
    GPIOA->AFR[0] &=~(1U<<11);

    GPIOA->MODER &= ~(1U<<6);
    GPIOA->MODER |= (1U<<7);
    GPIOA->AFR[0] |= (1U<<12);
    GPIOA->AFR[0] |= (1U<<13);
    GPIOA->AFR[0] |= (1U<<14);
    GPIOA->AFR[0] &= ~(1U<<15);

    // Habilita o clock da UART2
    RCC->APB1ENR |= UART2EN;

    // Configura o baudrate da UART
    uart_set_baudrate(USART2, APB1_CLK, UART_BAUDRATE);

    // Configura UART para enviar e receber
    USART2->CR1 = (CR1_TE | CR1_RE);
    USART2->CR1 |= (1U<<5);  // Habilita a interrupção RXNE (quando dados estiverem prontos para leitura)
    NVIC_EnableIRQ(USART2_IRQn);  // Habilita a interrupção USART2

    USART2->CR1 |= CR1_UE;  // Habilita a UART

    // Criação do semáforo binário para controlar acesso exclusivo à UART
    xUARTSemaphore = xSemaphoreCreateBinary();
    if (xUARTSemaphore != NULL) {
        xSemaphoreGive(xUARTSemaphore);  // Inicializa o semáforo como disponível
    }
}

// Função de leitura UART com verificação de semáforo e timeout
char uart2_read(void) {
    TickType_t xTimeout = pdMS_TO_TICKS(1000);  // Timeout de 1 segundo (ajuste conforme necessário)

    if (xSemaphoreTake(xUARTSemaphore, xTimeout) == pdTRUE) {
        while (!(USART2->SR & SR_RXNE)) {}  // Espera até a recepção de dados

        // Verificação de erros na UART antes de ler os dados
        uart_check_error(USART2);

        char received_data = USART2->DR;  // Lê os dados recebidos
        xSemaphoreGive(xUARTSemaphore);  // Libera o semáforo
        return received_data;
    } else {
        // Timeout: se o semáforo não foi adquirido a tempo
        return -1;  // Retorna um valor indicando falha
    }
}

void USART2_IRQHandler(void) {
    // Verifica se há dados recebidos
    if (USART2->SR & SR_RXNE) {
        // Lê os dados e libera o semáforo
        char received_char = USART2->DR;
        xSemaphoreGiveFromISR(xUARTSemaphore, NULL);  // Libera o semáforo
    }

    // Caso haja algum erro, trata-o
    uart_check_error(USART2);
}


// Função para enviar um caractere via UART
void uart2_write(int ch) {
    while (!(USART2->SR & SR_TXE)) {}  // Espera até o transmissor estar pronto

    USART2->DR = (ch & 0xFF);  // Envia o caractere via UART
}

// Função para definir o baudrate da UART
static void uart_set_baudrate(USART_TypeDef *USARTx, uint32_t PeriphClk, uint32_t BaudRate) {
    USARTx->BRR = compute_uart_bd(PeriphClk, BaudRate);
}

// Função para calcular o valor do baudrate para a UART
static uint16_t compute_uart_bd(uint32_t PeriphClk, uint32_t BaudRate) {
    return ((PeriphClk + (BaudRate/2U)) / BaudRate);
}

// Função para verificar erros da UART (Overrun, Noise)
static void uart_check_error(USART_TypeDef *USARTx) {
    if (USARTx->SR & (1U<<3)) {  // Overrun Error (ORE)
        USARTx->SR &= ~(1U<<3);  // Limpa o erro
        // Adicione um código de tratamento de erro aqui, se necessário
    }
    if (USARTx->SR & (1U<<1)) {  // Noise Error (NE)
        USARTx->SR &= ~(1U<<1);  // Limpa o erro
        // Adicione um código de tratamento de erro aqui, se necessário
    }
}
