#include "main.h"
#include "cmsis_os.h"
#include "usart.h"
#include "gpio.h"
#include <stdio.h>
#include <string.h>

#include "LCD1602.h"
#include "tim.h"
#include "uart.h"
#include "keypad.h"

#include "task.h"
#include "semphr.h"

#define LED GPIO_PIN_5

SemaphoreHandle_t xLCDSemaphore;
SemaphoreHandle_t xCounterSemaphore;
SemaphoreHandle_t xBinarySemaphore;
int cont = 0;

void keypad(void *pvParameters);
void UART(void *pvParameters);
void conta(void *pvParameters);
void toggleLedTask(void *pvParameters);

int main(void)
{
    MX_USART2_UART_Init();
    GPIO_init();
    tim2_init();
    keypad_init();
    lcd_init();

    lcd_put_cur(0, 0);
    lcd_send_string("SIST. TEMPO REAL");

    lcd_put_cur(1, 0);
    lcd_send_string("*    UNIFOR    *");
    delay(2000);

    lcd_clear();

    lcd_put_cur(0, 0);
    lcd_send_string("VOLT=");
    lcd_put_cur(0, 10);

    lcd_put_cur(1, 0);
    lcd_send_string("CONT=");

    lcd_put_cur(1, 10);
    lcd_send_string("UNIFOR");

    // Criação de semáforos
    xLCDSemaphore = xSemaphoreCreateBinary();
    xCounterSemaphore = xSemaphoreCreateBinary();
    xBinarySemaphore = xSemaphoreCreateBinary();

    // Inicialização dos semáforos
    xSemaphoreGive(xLCDSemaphore);
    xSemaphoreGive(xCounterSemaphore);
    xSemaphoreGive(xBinarySemaphore);

    // Criação das tarefas
    xTaskCreate(keypad, "Ler_teclas", 512, NULL, osPriorityNormal, NULL);
    xTaskCreate(conta, "Contador", 128, NULL, osPriorityNormal, NULL);
    xTaskCreate(toggleLedTask, "Toggle LED", 128, NULL, osPriorityNormal, NULL);
    xTaskCreate(UART, "UART", 256, NULL, osPriorityNormal, NULL);

    vTaskStartScheduler();

    return 0;
}


void keypad(void *pvParameters) {
    int bounce = 0;

    uint16_t key_val = 0;
    uint16_t key_Enter = 0;
    static char *key_name[] = {"RIGHT", "UP   ", "DOWN ", "LEFT ", "SELECT", "NONE  "};

    while (1) {
        key_val = keypad_read_key();
        key_Enter = key_val;
        int sensor_value = ADC1->DR;
        float volts = (sensor_value * 3.3) / 4096;

        if ((key_val == 4) && (bounce == 0)) {
            bounce++;
        } else {
            xSemaphoreTake(xLCDSemaphore, portMAX_DELAY);
            lcd_put_cur(0, 10);
            lcd_send_string(key_name[key_val]);

            char str[4];
            sprintf(str, "%.1f", volts);

            lcd_put_cur(0, 5);
            lcd_send_string(str);
            xSemaphoreGive(xLCDSemaphore);

            char txt1[20];
            xSemaphoreTake(xBinarySemaphore, portMAX_DELAY);
            sprintf(txt1, "VOLT =%.2fV\n", volts);
            HAL_UART_Transmit(&huart2, (uint8_t *)txt1, strlen(txt1), 100);
            xSemaphoreGive(xBinarySemaphore);

            while (key_val == KEY_UP) {
                key_val = keypad_read_key();
                if (key_val != KEY_UP && key_Enter == KEY_UP) {
                    cont++;
                    break;
                }
            }
            bounce = 0;
            vTaskDelay(pdMS_TO_TICKS(400));
        }
    }
}

//Tarefa02
void conta(void *pvParameters){
    char num_str[7];

    while (1){
        sprintf(num_str, "%d", cont);

        if (xSemaphoreTake(xLCDSemaphore, pdMS_TO_TICKS(50)) == pdTRUE){
          lcd_put_cur(1, 5);
          lcd_send_string("     ");
          lcd_put_cur(1, 5);
          lcd_send_string(num_str);

          xSemaphoreGive(xLCDSemaphore);
        }
        vTaskDelay(pdMS_TO_TICKS(200));
    }
}

void UART(void *pvParameters) {
    char receivedBuffer[6];
    char displayString[6];
    HAL_StatusTypeDef status;
    uint32_t num_bytes_recebidos = 0;
    uint8_t dummy_char_for_flush;

    while (1) {
        num_bytes_recebidos = 0;
        status = HAL_UART_Receive(&huart2, (uint8_t *)receivedBuffer, 5, 100);

        if (status == HAL_OK) {
            num_bytes_recebidos = 5;
        } else if (status == HAL_TIMEOUT) {
            if (5 >= huart2.RxXferCount) {
                 num_bytes_recebidos = 5 - huart2.RxXferCount;
            } else {
                 num_bytes_recebidos = 0;
            }
        } else {
            num_bytes_recebidos = 0;
        }

        if (num_bytes_recebidos > 0) {
            memset(displayString, ' ', 5);
            memcpy(displayString, receivedBuffer, num_bytes_recebidos);
            displayString[5] = '\0';
            if (xSemaphoreTake(xLCDSemaphore, pdMS_TO_TICKS(50)) == pdTRUE) {
                lcd_put_cur(1, 10);
                lcd_send_string("      ");
                lcd_put_cur(1, 10);
                lcd_send_string(displayString);
                xSemaphoreGive(xLCDSemaphore);
            }
            while (HAL_UART_Receive(&huart2, &dummy_char_for_flush, 1, 0) == HAL_OK) {}
        }
        vTaskDelay(pdMS_TO_TICKS(20));
    }
}


void toggleLedTask(void *pvParameters){
    while (1){
        HAL_GPIO_TogglePin(GPIOA, LED);
        vTaskDelay(pdMS_TO_TICKS(500));
    }
}

void SystemClock_Config(void){
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

    __HAL_RCC_PWR_CLK_ENABLE();
    __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE2);

    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
    RCC_OscInitStruct.HSIState = RCC_HSI_ON;
    RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
    RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
    RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
    RCC_OscInitStruct.PLL.PLLM = 16;
    RCC_OscInitStruct.PLL.PLLN = 336;
    RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
    RCC_OscInitStruct.PLL.PLLQ = 7;
    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK){
        Error_Handler();
    }

    RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
                                 | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
    RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK){
        Error_Handler();
    }
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim){

    if (htim->Instance == TIM2){
        BaseType_t xHigherPriorityTaskWoken = pdFALSE;
        xSemaphoreGiveFromISR(xBinarySemaphore, &xHigherPriorityTaskWoken);
        portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
    }
}

void Error_Handler(void){
    __disable_irq();
    while (1)
    {
    }
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{

}
#endif
